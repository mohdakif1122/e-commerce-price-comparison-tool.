import requests
from bs4 import BeautifulSoup
import re
from time import sleep
from random import randint, choice

# List of User-Agents to rotate
USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
    # Add more user agents if needed
]

# List of proxies to rotate
PROXY_LIST = [
    'http://111.111.111.111:8888',
    'http://222.222.222.222:8888',
    'http://333.333.333.333:8888',
    # Add more proxies if needed
]

def parse_price(price_str):
    """Helper function to clean and convert price strings to float."""
    price_str = price_str.replace(',', '')  # Remove commas
    price_str = re.sub(r'[^\d.]', '', price_str)  # Remove any non-digit characters except the period
    try:
        return float(price_str)
    except ValueError:
        return None

def fetch_html(url):
    """Helper function to fetch HTML content from a URL with retries, enhanced headers, and proxies."""
    session = requests.Session()  # Use a session to maintain cookies and headers
    for attempt in range(5):  # Retry logic
        headers = {
            'User-Agent': choice(USER_AGENTS),
            'Accept-Language': 'en-US,en;q=0.9',
            'Referer': 'https://www.google.com/',
            'Connection': 'keep-alive'
        }
        proxy = {'http': choice(PROXY_LIST)}
        try:
            response = session.get(url, headers=headers, proxies=proxy, timeout=10)
            print(f"Fetching URL: {url} (Attempt {attempt + 1}) with Proxy: {proxy['http']}")
            if response.status_code == 200:
                print("Successfully fetched the page.")
                return response.content
            elif response.status_code in [403, 503]:
                print(f"Server error ({response.status_code}). Retrying...")
                if "captcha" in response.text.lower():
                    print("Captcha detected. Sleeping longer...")
                    sleep(randint(30, 60))
                else:
                    sleep(randint(5, 10))  # Random delay between retries to avoid being blocked
            else:
                print(f"Failed to fetch the page. Status code: {response.status_code}")
                break
        except requests.exceptions.RequestException as e:
            print(f"Request failed: {str(e)}. Retrying...")
            sleep(randint(5, 10))  # Random delay between retries to avoid being blocked
    return None

def scrape_amazon(query):
    """Function to scrape Amazon for the given query."""
    search_url = f'https://www.amazon.in/s?k={query}'
    html_content = fetch_html(search_url)
    if html_content:
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            print("Parsing Amazon HTML content...")
            product_elements = soup.select('.s-main-slot .s-result-item')

            prices = []
            for product in product_elements:
                title = product.select_one('h2 .a-link-normal.a-text-normal')
                price = product.select_one('.a-price-whole')
                link = product.select_one('h2 .a-link-normal.a-text-normal')
                if title and price and link:
                    prices.append({
                        'site': 'Amazon',
                        'title': title.text.strip(),
                        'price': parse_price(price.text.strip()),
                        'link': 'https://www.amazon.in' + link['href']
                    })

            if not prices:
                print("No products found on Amazon.")
            return prices
        except Exception as e:
            print(f"Error parsing Amazon HTML: {str(e)}")
    return []

def scrape_flipkart(query):
    """Function to scrape Flipkart for the given query."""
    search_url = f'https://www.flipkart.com/search?q={query}'
    html_content = fetch_html(search_url)
    if html_content:
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            print("Parsing Flipkart HTML content...")
            product_elements = soup.select('._1AtVbE')

            prices = []
            for product in product_elements:
                title = product.select_one('._4rR01T')
                price = product.select_one('._30jeq3._1_WHN1')
                link = product.select_one('a._1fQZEK')
                if title and price and link:
                    prices.append({
                        'site': 'Flipkart',
                        'title': title.text.strip(),
                        'price': parse_price(price.text.strip()),
                        'link': 'https://www.flipkart.com' + link['href']
                    })

            if not prices:
                print("No products found on Flipkart.")
            return prices
        except Exception as e:
            print(f"Error parsing Flipkart HTML: {str(e)}")
    return []

def scrape_etsy(query):
    """Function to scrape Etsy for the given query."""
    search_url = f'https://www.etsy.com/search?q={query}'
    html_content = fetch_html(search_url)
    if html_content:
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            print("Parsing Etsy HTML content...")
            product_elements = soup.select('.v2-listing-card__info')

            prices = []
            for product in product_elements:
                title = product.select_one('.v2-listing-card__title')
                price = product.select_one('.currency-value')
                link = product.select_one('a')
                if title and price and link:
                    prices.append({
                        'site': 'Etsy',
                        'title': title.text.strip(),
                        'price': parse_price(price.text.strip()),
                        'link': link['href']
                    })

            if not prices:
                print("No products found on Etsy.")
            return prices
        except Exception as e:
            print(f"Error parsing Etsy HTML: {str(e)}")
    return []

def scrape_craigslist(query):
    """Function to scrape Craigslist for the given query."""
    search_url = f'https://craigslist.org/search/sss?query={query}'
    html_content = fetch_html(search_url)
    if html_content:
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            print("Parsing Craigslist HTML content...")
            product_elements = soup.select('.result-row')

            prices = []
            for product in product_elements:
                title = product.select_one('.result-title')
                price = product.select_one('.result-price')
                link = product.select_one('.result-title')
                if title and price and link:
                    prices.append({
                        'site': 'Craigslist',
                        'title': title.text.strip(),
                        'price': parse_price(price.text.strip()),
                        'link': link['href']
                    })

            if not prices:
                print("No products found on Craigslist.")
            return prices
        except Exception as e:
            print(f"Error parsing Craigslist HTML: {str(e)}")
    return []

# Example usage:
if __name__ == "__main__":
    query = "macbook air m3"
    amazon_results = scrape_amazon(query)
    flipkart_results = scrape_flipkart(query)
    etsy_results = scrape_etsy(query)
    craigslist_results = scrape_craigslist(query)

    all_results = amazon_results + flipkart_results + etsy_results + craigslist_results

    for result in all_results:
        print(result)
