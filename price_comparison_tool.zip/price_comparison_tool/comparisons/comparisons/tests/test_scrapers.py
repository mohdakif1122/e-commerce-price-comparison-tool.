# comparisons/tests/test_scrapers.py
import unittest
from unittest.mock import patch, MagicMock
from comparisons.scrapers import scrape_amazon, scrape_flipkart, scrape_reliance_digital, scrape_tatacliq

class ScraperTests(unittest.TestCase):

    @patch('comparisons.scrapers.requests.get')
    def test_scrape_amazon(self, mock_get):
        mock_response = MagicMock()
        mock_response.content = '''
        <html>
        <div class="s-result-item">
            <h2><a href="product1_link">Product 1</a></h2>
            <span class="a-price-whole">1000</span>
        </div>
        <div class="s-result-item">
            <h2><a href="product2_link">Product 2</a></h2>
            <span class="a-price-whole">2000</span>
        </div>
        </html>
        '''
        mock_get.return_value = mock_response

        url = 'https://www.amazon.in/s?k=test'
        results = scrape_amazon(url)

        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]['title'], 'Product 1')
        self.assertEqual(results[0]['price'], '1000')
        self.assertEqual(results[1]['title'], 'Product 2')
        self.assertEqual(results[1]['price'], '2000')

    @patch('comparisons.scrapers.requests.get')
    def test_scrape_flipkart(self, mock_get):
        mock_response = MagicMock()
        mock_response.content = '''
        <html>
        <div class="_1AtVbE">
            <a class="_1fQZEK" href="product1_link">
                <div class="_4rR01T">Product 1</div>
                <div class="_30jeq3">1000</div>
            </a>
        </div>
        <div class="_1AtVbE">
            <a class="_1fQZEK" href="product2_link">
                <div class="_4rR01T">Product 2</div>
                <div class="_30jeq3">2000</div>
            </a>
        </div>
        </html>
        '''
        mock_get.return_value = mock_response

        url = 'https://www.flipkart.com/search?q=test'
        results = scrape_flipkart(url)

        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]['title'], 'Product 1')
        self.assertEqual(results[0]['price'], '1000')
        self.assertEqual(results[1]['title'], 'Product 2')
        self.assertEqual(results[1]['price'], '2000')

    @patch('comparisons.scrapers.requests.get')
    def test_scrape_reliance_digital(self, mock_get):
        mock_response = MagicMock()
        mock_response.content = '''
        <html>
        <div class="sp__item">
            <a class="sp__name" href="product1_link">Product 1</a>
            <div class="sp__price">1000</div>
        </div>
        <div class="sp__item">
            <a class="sp__name" href="product2_link">Product 2</a>
            <div class="sp__price">2000</div>
        </div>
        </html>
        '''
        mock_get.return_value = mock_response

        url = 'https://www.reliancedigital.in/search?q=test'
        results = scrape_reliance_digital(url)

        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]['title'], 'Product 1')
        self.assertEqual(results[0]['price'], '1000')
        self.assertEqual(results[1]['title'], 'Product 2')
        self.assertEqual(results[1]['price'], '2000')

    @patch('comparisons.scrapers.requests.get')
    def test_scrape_tatacliq(self, mock_get):
        mock_response = MagicMock()
        mock_response.content = '''
        <html>
        <div class="Grid__element">
            <a class="ProductModule__link" href="product1_link">
                <div class="ProductModule__title">Product 1</div>
                <div class="Price__value">1000</div>
            </a>
        </div>
        <div class="Grid__element">
            <a class="ProductModule__link" href="product2_link">
                <div class="ProductModule__title">Product 2</div>
                <div class="Price__value">2000</div>
            </a>
        </div>
        </html>
        '''
        mock_get.return_value = mock_response

        url = 'https://www.tatacliq.com/search/?searchCategory=all&text=test'
        results = scrape_tatacliq(url)

        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]['title'], 'Product 1')
        self.assertEqual(results[0]['price'], '1000')
        self.assertEqual(results[1]['title'], 'Product 2')
        self.assertEqual(results[1]['price'], '2000')

if __name__ == '__main__':
    unittest.main()
