# comparisons/forms.py
from django import forms

class ProductSearchForm(forms.Form):
    product_name = forms.CharField(label='Product Name', max_length=100)
