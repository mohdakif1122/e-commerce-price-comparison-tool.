import requests
from bs4 import BeautifulSoup
import re
import certifi  # Import certifi


def parse_price(price_str):
    """Helper function to clean and convert price strings to float."""
    price_str = price_str.replace(',', '')  # Remove commas
    price_str = re.sub(r'[^\d.]', '', price_str)  # Remove any non-digit characters except the period
    return float(price_str)


def scrape_amazon(query):
    """Function to scrape Amazon for the given query."""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    search_url = f'https://www.amazon.in/s?k={query}'
    try:
        response = requests.get(search_url, headers=headers, verify=certifi.where())  # Use certifi for SSL verification
        soup = BeautifulSoup(response.content, 'html.parser')
        product_elements = soup.select('.s-main-slot .s-result-item')

        prices = []
        for product in product_elements:
            title = product.select_one('h2 .a-link-normal.a-text-normal')
            price = product.select_one('.a-price-whole')
            link = product.select_one('h2 .a-link-normal.a-text-normal')['href']

            if title and price and link:
                prices.append({
                    'site': 'Amazon',
                    'title': title.text.strip(),
                    'price': parse_price(price.text.strip()),
                    'link': 'https://www.amazon.in' + link
                })

        return prices
    except requests.exceptions.SSLError as e:
        print(f"SSL Error: {str(e)}")
        return []


