from django.shortcuts import render
from .scrapers import scrape_amazon, scrape_flipkart, scrape_etsy, scrape_craigslist

def home(request):
    return render(request, 'comparisons/home.html')

def search_results(request):
    query = request.GET.get('query')
    amazon_prices = scrape_amazon(query)
    flipkart_prices = scrape_flipkart(query)
    etsy_prices = scrape_etsy(query)
    craigslist_prices = scrape_craigslist(query)
    context = {
        'query': query,
        'amazon_prices': amazon_prices,
        'flipkart_prices': flipkart_prices,
        'etsy_prices': etsy_prices,
        'craigslist_prices': craigslist_prices
    }
    return render(request, 'comparisons/results.html', context)
