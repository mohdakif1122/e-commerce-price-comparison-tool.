import requests
from bs4 import BeautifulSoup
import logging
from django.core.management.base import BaseCommand
from comparisons.models import Product, Price
import certifi

logger = logging.getLogger(__name__)

# Define a helper function for parsing prices
def parse_price(price_str):
    """Helper function to clean and convert price strings to float."""
    return float(price_str.replace('₹', '').replace(',', '').strip())

# Define a scraper function for each store
def scrape_amazon(soup):
    price_tag = soup.find('span', {'class': 'a-price-whole'})
    if price_tag:
        return parse_price(price_tag.text), 'Amazon'
    return None, None

def scrape_flipkart(soup):
    price_tag = soup.find('div', {'class': '_30jeq3 _16Jk6d'})
    if price_tag:
        return parse_price(price_tag.text), 'Flipkart'
    return None, None

def scrape_etsy(soup):
    price_tag = soup.find('span', {'class': 'currency-value'})
    if price_tag:
        return parse_price(price_tag.text), 'Etsy'
    return None, None

def scrape_craigslist(soup):
    price_tag = soup.find('span', {'class': 'result-price'})
    if price_tag:
        return parse_price(price_tag.text), 'Craigslist'
    return None, None

# Mapping URLs to scraper functions
SCRAPER_FUNCTIONS = {
    'amazon.in': scrape_amazon,
    'flipkart.com': scrape_flipkart,
    'etsy.com': scrape_etsy,
    'craigslist.org': scrape_craigslist,
}

class Command(BaseCommand):
    help = 'Scrape prices from e-commerce websites'

    def handle(self, *args, **kwargs):
        product_name = "2020 MacBook Air M1, 8GB unified memory and 256GB SSD"
        urls = [
            'https://www.amazon.in/dp/B08N5VSQNG',
            'https://www.flipkart.com/apple-macbook-air-m1/p/itmde62d4c92e5a7',
            'https://www.etsy.com/listing/123456789/example-product',
            'https://craigslist.org/search/sss?query=macbook+air+m1',
        ]

        for url in urls:
            try:
                response = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'}, verify=certifi.where())
                response.raise_for_status()
                soup = BeautifulSoup(response.text, 'html.parser')

                domain = next((key for key in SCRAPER_FUNCTIONS.keys() if key in url), None)
                if domain:
                    price, store_name = SCRAPER_FUNCTIONS[domain](soup)
                    if price is not None and store_name is not None:
                        product, created = Product.objects.get_or_create(name=product_name)
                        Price.objects.create(product=product, store_name=store_name, price=price, url=url)
                        logger.info(f'Successfully scraped {store_name} for {product_name}: {price}')
                    else:
                        logger.warning(f'Could not find price information for URL: {url}')
                else:
                    logger.warning(f'No scraper function found for URL: {url}')

            except requests.RequestException as e:
                logger.error(f'Error fetching URL {url}: {e}')
            except Exception as e:
                logger.error(f'Unexpected error: {e}')
