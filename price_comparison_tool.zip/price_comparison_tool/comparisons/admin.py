from django.contrib import admin
from .models import Product, Price

admin.site.register(Product)
admin.site.register(Price)
