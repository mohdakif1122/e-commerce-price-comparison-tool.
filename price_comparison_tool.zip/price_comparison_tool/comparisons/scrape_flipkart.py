import requests
from bs4 import BeautifulSoup
import re
import certifi  # Import certifi


def parse_price(price_str):
    """Helper function to clean and convert price strings to float."""
    price_str = price_str.replace(',', '')  # Remove commas
    price_str = re.sub(r'[^\d.]', '', price_str)  # Remove any non-digit characters except the period
    return float(price_str)


def scrape_flipkart(query):
    """Function to scrape Flipkart for the given query."""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    search_url = f'https://www.flipkart.com/search?q={query}'
    try:
        response = requests.get(search_url, headers=headers, verify=certifi.where())  # Use certifi for SSL verification
        soup = BeautifulSoup(response.content, 'html.parser')
        product_elements = soup.select('._1AtVbE')

        prices = []
        for product in product_elements:
            title = product.select_one('._4rR01T')
            price = product.select_one('._30jeq3')
            link = product.select_one('a._1fQZEK')['href']

            if title and price and link:
                prices.append({
                    'site': 'Flipkart',
                    'title': title.text.strip(),
                    'price': parse_price(price.text.strip()),
                    'link': 'https://www.flipkart.com' + link
                })

        return prices
    except requests.exceptions.SSLError as e:
        print(f"SSL Error: {str(e)}")
        return []

# Example usage
# scrape_flipkart("foam shoes")
