# comparisons/models.py

from django.db import models

class Product(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name

class Price(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='prices')
    amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)  # Set a default value
    store_name = models.CharField(max_length=255)
    price = models.FloatField()
    url = models.URLField()

    def __str__(self):
        return f"{self.store_name} - ${self.price}"
