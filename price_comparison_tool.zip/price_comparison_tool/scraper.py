# scraper.py
import requests
from bs4 import BeautifulSoup
from decimal import Decimal

def scrape_amazon(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    prices = []

    # Example scraping logic (adjust based on actual site structure)
    products = soup.find_all('div', {'class': 's-result-item'})
    for product in products:
        price_span = product.find('span', {'class': 'a-offscreen'})
        if price_span:
            price_value = price_span.text.strip()
            price_value = Decimal(price_value.replace('₹', '').replace(',', ''))
            prices.append(price_value)

    return prices

def scrape_flipkart(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    prices = []

    products = soup.find_all('div', {'class': '_1AtVbE'})
    for product in products:
        price_div = product.find('div', {'class': '_30jeq3'})
        if price_div:
            price_value = price_div.text.strip()
            price_value = Decimal(price_value.replace('₹', '').replace(',', ''))
            prices.append(price_value)

    return prices

def scrape_reliance_digital(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    prices = []

    products = soup.find_all('div', {'class': 'sp__product'})
    for product in products:
        price_span = product.find('span', {'class': 'sc__price'})
        if price_span:
            price_value = price_span.text.strip()
            price_value = Decimal(price_value.replace('₹', '').replace(',', ''))
            prices.append(price_value)

    return prices

def scrape_tatacliq(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    prices = []

    products = soup.find_all('div', {'class': 'product-tuple-listing'})
    for product in products:
        price_span = product.find('span', {'class': 'product-price'})
        if price_span:
            price_value = price_span.text.strip()
            price_value = Decimal(price_value.replace('₹', '').replace(',', ''))
            prices.append(price_value)

    return prices
